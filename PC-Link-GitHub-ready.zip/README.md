# PC-Link Project

**Offline, cableless, Wi-Fi-less PC-to-PC communication system**

## Features
- Works without Wi-Fi, Bluetooth, or cables
- AI-enhanced signal decoding
- Short-range secure communication
- Can transfer messages, files, and commands

## Folder Structure
```
PC-Link-Project/
├── README.md
├── LICENSE
├── .gitignore
├── hardware/
├── ai/
├── firmware/
└── docs/
```

## Usage
- All instructions to run AI model and firmware are inside their respective folders.

## Notes
- This project is for your personal development.
- No need to follow contributing guidelines if you are the only developer.

## Author
Tarun Kumar Saxena (User)

AI Co-Developer Assistance: ChatGPT
